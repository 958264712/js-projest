# guitar tab produce

example:

![](http://ofphfz209.bkt.clouddn.com/ywaq.png)